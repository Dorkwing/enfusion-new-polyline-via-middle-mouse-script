Step 1. dowload auto hotkey
step 2. place the "enfusion_polyline_middle_mouse_.ahk" in C:\Users\Admin\Documents\AutoHotkey
        (you may need to edit the directory in "arma reforger tools shortcut.ahk" if youre username isnt admin)
step 3. Place the Arma Reforger Tools Shortcut file on your desktop and use this to open enfusion from now on
Step 4. press middle mouse button to add a new polyline wherever you had your mouse 
